int a1;
int a2;

for(int i=0; i<3; i++)
{
    a1=3*i;
    a2= a1+3;
    a2= a2 - i;
}

int fun (int x) {
    a1 = x*x;
    return a1;
}

int a3 = fun(6);

